// src/components/media/SeasonCarousel.tsx
import { Link } from "react-router-dom";
import type { Season } from "../../types/Tv";
import CarouselRow from "../ui/CarouselRow";

interface Props {
	seasons?: Season[];
	tvId: number;
}

export default function SeasonCarousel({ seasons = [], tvId }: Props) {
	if (!seasons.length) return null;

	return (
		<CarouselRow>
			{seasons.map((s) => {
				const poster = s.poster_path
					? `https://image.tmdb.org/t/p/w185${s.poster_path}`
					: "/no-image.png";

				return (
					<Link
						key={s.id}
						to={`/tv/${tvId}/season/${s.season_number}`}
						className="
                            flex w-40 shrink-0 flex-col rounded-lg border 
                            p-2 text-left text-xs transition-transform 
                            hover:-translate-y-1 border-token bg-surface-alt/80
                            hover:bg-surface-alt
                        "
					>
						<img
							src={poster}
							alt={s.name}
							className="mb-2 h-40 w-full rounded-md object-cover"
						/>
						<p className="font-semibold line-clamp-2">{s.name}</p>

						{s.episode_count != null && (
							<p className="text-[11px] text-muted">
								{s.episode_count} episodes
							</p>
						)}
					</Link>
				);
			})}
		</CarouselRow>
	);
}
