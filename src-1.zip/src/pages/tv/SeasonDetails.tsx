// src/pages/tv/SeasonDetails.tsx
import { useEffect, useMemo, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

import type { TvShow, Season, Episode } from "../../types/Tv";
import { getTv, getTvSeason } from "../../services/api";

import Surface from "../../components/ui/Surface";
import SectionHeader from "../../components/ui/SectionHeader";
import EpisodeCard from "../../components/media/EpisodeCard";

export default function SeasonDetails() {
	const { id, seasonNumber } = useParams();
	const showId = Number(id);
	const seasonNum = Number(seasonNumber);
	const navigate = useNavigate();

	const [show, setShow] = useState<TvShow | null>(null);
	const [season, setSeason] = useState<Season | null>(null);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		if (!showId || !seasonNum) return;

		let cancelled = false;

		const load = async () => {
			setLoading(true);

			try {
				const [showRes, seasonRes] = await Promise.all([
					getTv(showId),
					getTvSeason(showId, seasonNum),
				]);

				if (cancelled) return;

				setShow(showRes);
				setSeason(seasonRes);
			} finally {
				if (!cancelled) setLoading(false);
			}
		};

		load();
		return () => {
			cancelled = true;
		};
	}, [showId, seasonNum]);

	const sortedSeasons = useMemo(() => {
		return show?.seasons
			? [...show.seasons].sort((a, b) => a.season_number - b.season_number)
			: [];
	}, [show]);

	const episodes: Episode[] = season?.episodes ?? [];

	if (!show) {
		return <div className="pt-24 pb-10 text-center text-muted">Loading…</div>;
	}

	return (
		<motion.div
			initial={{ opacity: 0 }}
			animate={{ opacity: 1 }}
			className="min-h-screen bg-background pt-20 pb-10"
		>
			{/* HERO */}
			<section className="mx-auto max-w-7xl mb-10 px-4 sm:px-6 lg:px-8">
				<div className="flex gap-6">
					<div className="hidden sm:block w-40 md:w-56 shrink-0">
						<img
							src={
								season?.poster_path
									? `https://image.tmdb.org/t/p/w500${season.poster_path}`
									: "/no-image.png"
							}
							className="rounded-xl border border-token object-cover shadow-card"
						/>
					</div>

					<div className="flex flex-col gap-3 flex-1">
						<Link
							to={`/tv/${showId}`}
							className="text-accent text-xs hover:underline"
						>
							← Back to {show.name}
						</Link>

						<h1 className="text-3xl font-semibold text-foreground">
							{season?.name}
						</h1>

						{season?.air_date && (
							<p className="text-muted text-sm">
								Aired:{" "}
								<span className="text-foreground">{season.air_date}</span>
							</p>
						)}

						{season?.overview && (
							<p className="text-sm text-muted max-w-2xl">{season.overview}</p>
						)}
					</div>
				</div>
			</section>

			{/* SWITCH SEASONS — redesigned */}
			<section className="mx-auto max-w-7xl mb-10 px-4 sm:px-6 lg:px-8">
				<Surface>
					<SectionHeader title="Switch Season" eyebrow="All Seasons" />
					<div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
						{sortedSeasons.map((s) => (
							<button
								key={s.id}
								onClick={() =>
									navigate(`/tv/${showId}/season/${s.season_number}`)
								}
								className={`flex rounded-xl border px-4 py-3 gap-4 text-left transition-colors ${
									s.season_number === seasonNum
										? "border-accent bg-surface-alt"
										: "border-token hover:border-accent"
								}`}
							>
								<img
									src={
										s.poster_path
											? `https://image.tmdb.org/t/p/w300${s.poster_path}`
											: "/no-image.png"
									}
									className="w-20 h-28 object-cover rounded-lg"
								/>
								<div className="flex flex-col justify-center">
									<span className="font-semibold text-foreground">
										{s.name}
									</span>
									<span className="text-sm text-muted">
										{s.episode_count} episodes
									</span>
								</div>
							</button>
						))}
					</div>
				</Surface>
			</section>

			{/* EPISODES — sequential fade */}
			<section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
				<Surface>
					<SectionHeader title="Episodes" eyebrow="Season Breakdown" />
					<div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
						{episodes.map((ep, index) => (
							<motion.div
								key={ep.id}
								initial={{ opacity: 0 }}
								animate={{ opacity: 1 }}
								transition={{
									duration: 0.4,
									delay: index * 0.05,
								}}
							>
								<EpisodeCard
									episode={ep}
									showId={showId}
									seasonNumber={seasonNum}
								/>
							</motion.div>
						))}
					</div>
				</Surface>
			</section>
		</motion.div>
	);
}
