// src/pages/tv/EpisodeDetails.tsx
import { useEffect, useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";

import type { Episode, Season } from "../../types/Tv";
import type { VideosResponse } from "../../types/Shared";

import {
	getTv,
	getTvSeason,
	getTvEpisode,
	getTvEpisodeVideos,
} from "../../services/api";

import Surface from "../../components/ui/Surface";
import SectionHeader from "../../components/ui/SectionHeader";
import TrailerCarousel from "../../components/media/TrailerCarousel";

interface RouteParams {
	id?: string;
	seasonNumber?: string;
	episodeNumber?: string;
}

export default function EpisodeDetails() {
	const { id, seasonNumber, episodeNumber } = useParams<RouteParams>();

	const showId = Number(id);
	const sNum = Number(seasonNumber);
	const eNum = Number(episodeNumber);

	const [episode, setEpisode] = useState<Episode | null>(null);
	const [season, setSeason] = useState<Season | null>(null);
	const [showName, setShowName] = useState("");
	const [videos, setVideos] = useState<VideosResponse | null>(null);

	const [loading, setLoading] = useState(true);
	const [error, setError] = useState<string | null>(null);

	useEffect(() => {
		if (!showId || !sNum || !eNum) return;

		let cancelled = false;

		const load = async () => {
			setLoading(true);
			setError(null);

			try {
				const [show, seasonRes, episodeRes, videosRes] = await Promise.all([
					getTv(showId),
					getTvSeason(showId, sNum),
					getTvEpisode(showId, sNum, eNum),
					getTvEpisodeVideos(showId, sNum, eNum),
				]);

				if (cancelled) return;

				setShowName(show.name);
				setSeason(seasonRes);
				setEpisode(episodeRes);
				setVideos(videosRes);
			} catch (err) {
				if (!cancelled) {
					setError(
						err instanceof Error
							? err.message
							: "Failed to load episode details"
					);
				}
			} finally {
				if (!cancelled) setLoading(false);
			}
		};

		void load();
		return () => {
			cancelled = true;
		};
	}, [showId, sNum, eNum]);

	// Extract credits from season
	const seasonEpisodeData = useMemo(() => {
		if (!season) return null;
		return season.episodes?.find((ep) => ep.episode_number === eNum) ?? null;
	}, [season, eNum]);

	const guestStars = seasonEpisodeData?.guest_stars ?? [];
	const crew = seasonEpisodeData?.crew ?? [];

	const directors = crew.filter((c) => c.job === "Director");
	const writers = crew.filter(
		(c) => c.department === "Writing" || c.job === "Writer"
	);

	const trailerVideos = useMemo(
		() =>
			(videos?.results ?? []).filter(
				(v) =>
					v.site === "YouTube" && (v.type === "Trailer" || v.type === "Teaser")
			),
		[videos]
	);

	if (loading && !episode) {
		return <div className="py-10 text-muted text-center">Loading episode…</div>;
	}

	if (error && !episode) {
		return (
			<div className="py-10 text-center text-red-400">Failed: {error}</div>
		);
	}

	if (!episode) return null;

	const still = episode.still_path
		? `https://image.tmdb.org/t/p/original${episode.still_path}`
		: "/no-image.png";

	return (
		<motion.div
			initial={{ opacity: 0 }}
			animate={{ opacity: 1 }}
			className="pb-10 pt-20"
		>
			{/* HERO */}
			<section className="relative -mx-4 mb-8 sm:mx-0">
				<div
					className="absolute inset-0 opacity-30 bg-cover bg-center"
					style={{ backgroundImage: `url(${still})` }}
				/>
				<div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />

				<div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
					<Link
						to={`/tv/${showId}/season/${sNum}`}
						className="text-accent text-xs hover:underline"
					>
						← Back to Season {sNum}
					</Link>

					<h1 className="mt-3 text-3xl font-semibold text-foreground">
						{showName} — S{sNum}E{eNum}: {episode.name}
					</h1>

					<p className="text-muted mt-2 text-sm max-w-xl">{episode.overview}</p>
				</div>
			</section>

			{/* DETAILS */}
			<section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-8">
				<Surface>
					<SectionHeader title="Episode Details" eyebrow="Information" />
					<div className="text-sm text-muted space-y-2">
						{episode.air_date && (
							<p>
								<span className="font-semibold text-foreground">Aired:</span>{" "}
								{episode.air_date}
							</p>
						)}
						{episode.vote_average != null && (
							<p>
								<span className="font-semibold text-foreground">Rating:</span>{" "}
								{episode.vote_average.toFixed(1)} / 10
							</p>
						)}
					</div>
				</Surface>
			</section>

			{/* CREW */}
			{(directors.length > 0 || writers.length > 0) && (
				<section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-8">
					<Surface>
						<SectionHeader title="Crew" eyebrow="Directed & Written By" />

						<div className="space-y-3 text-sm text-muted">
							{directors.length > 0 && (
								<p>
									<span className="font-semibold text-foreground">
										Director:
									</span>{" "}
									{directors.map((d) => d.name).join(", ")}
								</p>
							)}

							{writers.length > 0 && (
								<p>
									<span className="font-semibold text-foreground">Writer:</span>{" "}
									{writers.map((w) => w.name).join(", ")}
								</p>
							)}
						</div>
					</Surface>
				</section>
			)}

			{/* GUEST STARS */}
			{guestStars.length > 0 && (
				<section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-8">
					<Surface>
						<SectionHeader title="Guest Stars" eyebrow="Featured Cast" />
						<div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
							{guestStars.map((star) => (
								<Link
									key={star.id}
									to={`/person/${star.id}`}
									className="rounded-lg border border-token bg-surface-alt p-3 hover:bg-surface transition-colors"
								>
									<p className="font-medium text-foreground">{star.name}</p>
									<p className="text-xs text-muted">{star.character}</p>
								</Link>
							))}
						</div>
					</Surface>
				</section>
			)}

			{/* TRAILERS */}
			{trailerVideos.length > 0 && (
				<section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
					<Surface>
						<SectionHeader title="Episode Videos" eyebrow="Trailers & Clips" />
						<TrailerCarousel videos={trailerVideos} />
					</Surface>
				</section>
			)}
		</motion.div>
	);
}
